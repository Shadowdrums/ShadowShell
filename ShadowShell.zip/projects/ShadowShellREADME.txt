      ...                                    ..                                                ...                                      ..       .. 
   .x888888hx    :   .uef^"                 dF                       x=~                    .x888888hx    :   .uef^"               x .d88"  x .d88" 
  d88888888888hxx  :d88E                   '88bu.             u.    88x.   .e.   .e.       d88888888888hxx  :d88E                   5888R    5888R 
 8" ... `"*8888%`  `888E             u     '*88888bu    ...ue888b  '8888X.x888:.x888      8" ... `"*8888%`  `888E            .u     '888R    '888R 
!  "   ` .xnxx.     888E .z8k     us888u.    ^"*8888N   888R Y888r  `8888  888X '888k    !  "   ` .xnxx.     888E .z8k    ud8888.    888R     888R 
X X   .H8888888%:   888E~?888L .@88 "8888"  beWE "888L  888R I888>   X888  888X  888X    X X   .H8888888%:   888E~?888L :888'8888.   888R     888R 
X 'hn8888888*"   >  888E  888E 9888  9888   888E  888E  888R I888>   X888  888X  888X    X 'hn8888888*"   >  888E  888E d888 '88%"   888R     888R 
X: `*88888%`     !  888E  888E 9888  9888   888E  888E  888R I888>   X888  888X  888X    X: `*88888%`     !  888E  888E 8888.+"      888R     888R 
'8h.. ``     ..x8>  888E  888E 9888  9888   888E  888F u8888cJ888   .X888  888X. 888~    '8h.. ``     ..x8>  888E  888E 8888L        888R     888R 
 `88888888888888f   888E  888E 9888  9888  .888N..888   "*888*P"    `%88%``"*888Y"        `88888888888888f   888E  888E '8888c. .+  .888B .  .888B .
  '%8888888888*"   m888N= 888> "888*""888"  `"888*""      'Y"         `~     `"            '%8888888888*"   m888N= 888>  "88888%    ^*888%   ^*888% 
     ^"****""`      `Y"   888   ^Y"   ^Y'      ""                                             ^"****""`      `Y"   888     "YP"       "%       "% 
                         J88"                                                                                     J88"
                         @%                                                                                       @%
                       :"                                                                                        :"


-----------------------------------------------WELCOME TO SHADOW SHELL------------------------------------------------------------------
Shadow Shell is a Reverse shell written in python. 
Note: both devices will need python installed.
Note: this reverse shell is for windows to windows application.

Contributors:
.Shadowdrums
.DJ Stomp
.toroidist
---------------------------------------------------HOW TO USE---------------------------------------------------------------------------

1. In both client.py and server.py you will need to change FF.FF.FF.FF for the ip address of your computer(host).

2. Be sure to change the port's and that they match in both server and client. also to be safe make sure to make a firewall rule
   that only allows connection on the port youre going to use between your computer and the target computer and only those devices.

3. This application comes with a VBScript that you place in the target device startup folder and the Client.py in the Intel folder this will
   run client.py in the background on target device everytime the device is turned on.

4. ShadowShell1.3A.py is optional for using this application and its preferable sue is on the host device. the key to use the terminal is "7331"
   and can be changed to what ever you prefer though note it only excepts numbers and no special characters or letters. Also not that the file path the ShadowShell 
   uses is set for dsktop and a folder named projects and the server and client must be placed in that folder for the terminal to activate them if you
   chose to use it.

5. This will give you a reverse shell into a windows computer and allow the user to use the targets command prompt. if you would like to use powershell
   you must use "powerhsell -command yourCommand" other wise the program will freeze and crash and you will have to reconnect.

-----------------------------------------------------------DISCLAIMER------------------------------------------------------------------------
THIS APPLICATION WAS MADE FOR EDUCATION PURPOSES
DEVELOPER WILL NOT BE HELD LIABLE FOR ANY MISS
USE WITH THIS SOURCE CODE. DO NOT USE ON ANY
DEVICE THAT IS NOT YOURES UNLESS YOU HAVE
DOCUMENTED APPROVAL FROM THE OWNER OF THE DEVICES

+--------------+
|  SHADOWDRUMS |
|          TM  |
|              |
|              |
+--------------+ 